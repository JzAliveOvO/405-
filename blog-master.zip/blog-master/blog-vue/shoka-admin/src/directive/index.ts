export { hasPerm, hasRole } from "./permission";
