<template>
  <div class="common-layout">
    <el-container>
      <el-header class="header">
        <Header />
      </el-header>
      <el-main>
        <div class="main">
          <div class="card-wrapper">
            <el-card style="width: 1000px; height: 520px;">
              <template #header>
                <div class="card-header" style="text-align: left;">
                  <span>好友动态</span>
                </div>
              </template>
              <p v-for="o in 4" :key="o" class="text item"></p>
            </el-card>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import Header from '@/components/Header.vue';

export default {
  components: {
    Header,
  },
};
</script>

<style scoped>
html, body {
    margin: 0;
    padding: 0;
    height: 100%;
}

.header {
    position: sticky; /* 设置为粘性定位 */
    top: 0; /* 距离顶部为0 */
    z-index: 10; /* 提高层级，确保其在其他元素之上 */
    margin: 0; /* 清除外边距 */
    padding: 0; /* 清除内边距 */
}

.main {
    width: 100%;
    height: calc(100vh - 64px); /* 减去 Header 的高度（根据实际情况调整） */
    background-color: #f0f0f0; /* 浅灰色背景 */
    display: flex; /* 使用 flexbox 布局 */
    justify-content: center; /* 水平居中 */
    align-items: center; /* 垂直居中 */
}

.card-wrapper {
    display: flex; /* 使用 flexbox 布局 */
    justify-content: center; /* 水平居中 */
    width: 100%; /* 设置宽度 */
    height: 100%; /* 设置高度 */
}
</style>



  