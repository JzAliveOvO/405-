<template>
  <div class="bo"> 
    <!-- 卡片 -->
    <el-card class="card">
        <h1 style="text-align: center;">欢迎使用</h1>
      <!-- 登录 or 注册 -->
      <el-radio-group v-model="choose" class="radioGroup" size="small">
        <el-radio-button style="margin-bottom:20px;margin-top:18px" type="seccess" plain label="login">登录</el-radio-button>
        <el-radio-button style="margin-bottom:20px;margin-top:18px" type="seccess" plain label="signIn">注册</el-radio-button>
      </el-radio-group>
      <!-- user输入表单 -->
      <el-form label-position="right" label-width="80px" :model="user">
        <el-form-item v-if="choose==='login'"
          label="账号"
          prop="uid"
          :rules="[ { required: true, message: '请输入账号', trigger: 'blur' } ]">
          <el-input v-model="user.uid"></el-input>
        </el-form-item>
        <el-form-item v-if="choose==='signIn'"
          label="账号"
          prop="uid"
          :rules="[ { required: true, message: '请输入账号', trigger: 'blur' } ]">
          <el-input v-model="user.uid"></el-input>
        </el-form-item>
        <el-form-item
          label="密码"
          prop="password"
          :rules="[ { required: true, message: '请输入密码', trigger: 'blur' } ]">
          <el-input type="password" v-model="user.password" show-password></el-input>
        </el-form-item>
        <el-form-item
          v-if="choose==='signIn'"
          label="确认密码"
          prop="checkPassword"
          :rules="[ { required: true, message: '请输入再次输入密码', trigger: 'blur' } ]">
          <el-input type="password" v-model="user.checkPassword" show-password></el-input>
        </el-form-item>
        <el-form-item v-if="choose==='signIn'"
          label="姓名"
          prop="uname"
          :rules="[ { required: true, message: '请输入姓名', trigger: 'blur' } ]">
          <el-input v-model="user.uname"></el-input>
        </el-form-item>
        <el-form-item v-if="choose==='signIn'"
          label="性别"
          prop="usex"
          :rules="[ { required: true, message: '请输入性别', trigger: 'blur' } ]">
          <el-input v-model="user.usex"></el-input>
        </el-form-item>
        <!--按钮-->
        <el-button v-if="choose==='login'" type="success" @click="login"
        :disabled="user.ID===''||user.password===''" plain>登录
        </el-button>
        <el-button v-if="choose==='signIn'" type="success" plain @click="signIn"
        :disabled="user.ID===''||user.password===''||user.checkPassword===''" >注册
        </el-button>
        <el-button @click="reset" plain>清空</el-button>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import router from '@/router'
export default{
  data(){
   return{
    choose: 'login', 
    user: {
        uid: '',
        password: '',
        checkPassword: '',
        uname:'',
        usex:'',
   },
   response: null,
   }
  },
  methods:{
       //注册
    async signIn() {
      if (this.user.checkPassword !== this.user.password) {
            this.$message.error("两次输入的密码不一致!")
          }else{
      try{ 
        const response = await fetch("http://127.0.0.1:5553/api/register_user", {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            uid:this.user.uid,
            uname: this.user.uname,
            password: this.user.password,
            usex:this.user.usex
          }),
        });
        // 检查 HTTP 状态码
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.code === 201 ) {
          console.log('SignIn successful');
          this.$message.success("注册成功!"); // 显示成功消息
        }else{
          console.error('SignIn failed, error message:', data.message || 'Unknown error');
        }
      } catch (error) {
        console.error('请求失败：', error);
        this.$message.success("注册失败!"); // 显示成功消息
      }
    }},
    //登录
    async login() {
      try {
        const response = await fetch("http://127.0.0.1:5553/api/login", {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json', 
          },
          body: JSON.stringify({
            uid: this.user.uid,
            password: this.user.password,
          }),
        });
        // 检查 HTTP 状态码
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
        if (data.code === 200) {
          localStorage.setItem('uid',data.data.uno)
          localStorage.setItem('jwtToken', data.data.access_token);
          localStorage.setItem('jwtTokenNew',data.data.refresh_token);
          console.log('Login successful, redirecting to home');
          router.push('/Home');
        } else {
          console.error('Login failed, error message:', data.message || 'Unknown error');
          this.$message.error("密码或账号错误!");
        }
      } catch (error) {
        router.push('/Home');
        console.error('请求失败：', error); 
        //this.$message.error("密码或账号错误!");
      }
    },
    // 重置表单
    reset() {
      this.user.uid = ""
      this.user.password = ""
      this.user.checkPassword = ""
      this.user.uname=""
      this.user.usex=""
    }
  }
}
</script>

<style>
.card{
  width: 450px;
  margin: 120px 100px 0 auto;
  height: 550px;
  position: relative; 
  z-index: 1; 
}
 
 
</style>

