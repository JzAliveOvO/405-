<template>
    <div>
      <Header />
      <div class="main">
        <h1>个人主页</h1>
      </div>
    </div>
  </template>
  
  <script>
  import Header from '@/components/Header.vue';
  
  export default {
    components: {
      Header,
    },
  };
  </script>
  
  <style scoped>
html, body {
    margin: 0;
    padding: 0;
    height: 100%;
}

.header {
    position: sticky; /* 设置为粘性定位 */
    top: 0; /* 距离顶部为0 */
    z-index: 10; /* 提高层级，确保其在其他元素之上 */
    margin: 0; /* 清除外边距 */
    padding: 0; /* 清除内边距 */
}

  .main {
      width: 100%;
      height: 100vh; /* 使用视口高度填满 */
      background-color: #f0f0f0; /* 浅灰色背景 */
      display: flex; /* 使用 flexbox 布局 */
      justify-content: center; /* 水平居中 */
      align-items: center; /* 垂直居中 */
  }
  </style>